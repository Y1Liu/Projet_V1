###############################################################################
#Fichier permettant de lancer l'application Flask
#Par Arnaud Duhamel et Robin Cavalieri
#Planificateur intelligent
#SOLUTEC Paris
#06/04/2018
###############################################################################

#from flask import render_template, flash, redirect
from app import app
#from app.forms import TrajectForm

