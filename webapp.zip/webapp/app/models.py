#from app import db

#class Trajet(db.Model):
#	id = db.Column(db.Integer, primary_key=True)
#	depart=db.Column(db.String(64), index=True)
#	arrivee=db.Column(db.String(64), index=True)
#	mode=db.Column(db.String(10))